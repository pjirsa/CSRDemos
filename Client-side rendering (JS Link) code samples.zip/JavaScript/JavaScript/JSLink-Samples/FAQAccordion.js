﻿// List View – FAQ Accordion Sample
// Muawiyah Shannak , @MuShannak

(function () {

    // jQuery library is required in this sample
    // Fallback to loading jQuery from a CDN path if the local is unavailable
    (window.jQuery || document.write('<script src="//ajax.aspnetcdn.com/ajax/jquery/jquery-1.10.0.min.js"><\/script>'));

    // Create object that have the context information about the field that we want to change it output render 
    var FAQContext = {};
    FAQContext.Templates = {};

    // Be careful when add the header for the template, because it's will break the default list view render
    FAQContext.Templates.Header = "<div class='accordion'>";
    FAQContext.Templates.Footer = "</div>";

    // Add OnPostRender event handler to add accordion click events and style
    FAQContext.OnPostRender = FAQOnPostRender;

    // This line of code tell TemplateManager that we want to change all HTML for item row render
    FAQContext.Templates.Item = FAQTemplate;

    SPClientTemplates.TemplateManager.RegisterTemplateOverrides(FAQContext);

})();

// This function provides the rendering logic
function FAQTemplate(ctx) {
    var title = ctx.CurrentItem["Title"];
    var description = ctx.CurrentItem["Description"];

    // Return whole item html
    return "<h2>" + title + "</h2><p>" + description + "</p><br/>";
}

function FAQOnPostRender() {

    // Register event to collapse and uncollapse when click on FAQ header
    $('.accordion h2').click(function () {
        $(this).next().slideToggle();
    }).next().hide();

    $('.accordion h2').css('cursor', 'pointer');
}